CODENAME: PANZERS - PHASE II
www.stormregion.com

PATCH VERSION 1.07 International 15th February 2007

IMPORTANT NOTE: Make sure you have your game at version 1.06 before applying this patch. Patch 1.06 is available for download at www.stormregion.com.

------------------------------------------------------------------------
Patch v1.07 Changes

PANZERS Vista update

- Modified the game's executable file so that it is able to run on Microsoft's new operating system: Windows Vista.
- Fixed the Superspeed effect bug related to Hyperthreading.
- Fixed the Superspeed effect bug related to Dual-core Laptop computers. 
- CD Protection (Starforce) has been removed, the original CD is no longer needed during gameplay.
  
  Savegames from versions prior to 1.06 can be loaded after installing this patch.
  
------------------------------------------------------------------------

INSTALLATION

Simply replace or overwrite the old PANZERS_PHASE_2.exe file which is located in your games RUN directory (the default location is C:\Program Files\PANZERS - Phase2\Run\) with the new one included in this zip file.
When you start the program, in the upper right corner you should see version number 1.07.

Enjoy the game!


Stormregion

------------------------------------------------------------------------

IMPORTANT


All firewall users please ensure that UDP-port 5555 and 6500 are enabled

-How do I configure my router to host a multiplayer game using the build-in Gamespy-client of Codename:Panzers ?
Please ensure that UDP-port 5555 and 6500 are accessible from the internet and forwarded to the local PC where Codename:Panzers is installed. For outgoing connections to the internet you have to forward UDP-Ports 13139, 
27900 and 28910.

Detailed description:
http://www.panzers.de/support/dsl_router_eng.htm

-------------------
Patch v1.06 Changes

** New features:
-Cooperative mode for single player maps (maps with no unit purchase is unavailable, sorry)
Important: you must win a mission in single player in order to use it in cooperative mode
Restrictions: pause and save/load is not available in cooperative (as in multiplayer)
-Unit limit for maps is in effect from now on (it will decrease the lag on multiplayer maps with a lots of unit)
-Players can give units to other players in multiplayer (and for allied AI player too) and in cooperative mode
Usage in cooperative mode: select the units you wish to give then click on the Unit transfer button (third button right to the minimap)
Usage in multiplayer mode: select the units you wish to give then click on the Unit transfer button (third button right to the minimap) then click on a unit belong to the player you wish to give the unit

** Enhancements
-Speed of the map download has been increased

** New multimaps
Team Match
(4) River Crossing

Domination
(4) Forest
(6) To Hell And Back
(8) Europe at war
(8) Rush Hour
(8) The Longest Day
(8) Silent Hill

MP Mission
(4) Saturday night fever added (it's now a four player map)

** General Bugfixes:
-The !Test in game! button in the Level editor works now
-Several small bugs have been fixed


-------------------
Patch v1.05 Changes

** New features:
-The game now runs on Windows XP x64 Edition (StarForce has been updated)
-You can enter the staging room by double clicking
-in the chat window the team, general and system messages are displayed with different colors
-the double-click option has the same functionality as join option for password protected MP games
-from now on, drop containers can be destroyed

** New multimaps
Team Match
(4) Hill
Domination
(4) Field
(4) Iron Cross


** General Bugfixes:
-various display bugs occurring in cutscenes (when switching camera angles,etc) have been fixed
-errors while using campaign selection menu have been corrected
-"Add Buddy" button in GamespyTitleRoom works now
-unit stats errors in headquarters menu have been fixed
-random crashes occurring upon loading savegames have been eliminated
-the number of tanks available for purchase in Campaign and Skirmish mode has been limited to 10, 
no cheats possible :)
-sound problems using Creative Labs EAX Sound Drivers corrected
-memory leak issues corrected
-some unit selection icons occurring in cutscenes have been removed
-Small enhancments on objects
-missing unit speeches added
-Several small bugs have been fixed

** Map fixes:

Single player maps:
-al-07 Monte Cassino (Enhanced gameplay speed)
-al-08 Anzio-Cisterna (Enhanced gameplay speed)
-yu-02 Running the Gauntlet (Better balancement)

Multimaps:
-Road to perdition (Modified landscape)
-Fortress mania (Enhanced screen messages)
-Gun-ho (Units can't "go into" the railway gun)

** Better balancement for
-Ge Marder II
-SU Is-2
-SU Isu-152
-SU KV-2
-SU SU-85
-US Dodge WC 57

** Interface
-Small enhancements
-Fixed text